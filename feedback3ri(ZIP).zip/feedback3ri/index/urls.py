from django.contrib import admin
from django.urls import path
from .views import home,contact,about,register,signin,feedback,cources,python,aws,datascience,selenium,signout,tableau,datasciencepy


urlpatterns = [
    path('admin/', admin.site.urls),
    path('',home,name="home"),
    path('contact/',contact,name="contact"),
    path('about/',about,name="about"),
    path('signup/',register,name="signup"),
    path('signin/',signin,name="signin"),
    path('feedback/',feedback,name="feedback"),
    path('cources/',cources,name="cources"),
    path('python/',python,name="python"),
    path('aws/',aws,name="aws"),
    path('datascience/',datascience,name="datascience"),
    path('selenium/',selenium,name="selenium"),
    path('logout/',signout,name="signout"),
    path('datasciencepy/',datasciencepy,name="datasciencepy"),
    path('tableau/',tableau,name="tableau"),

]