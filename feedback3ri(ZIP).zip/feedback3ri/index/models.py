from django.db import models

class user(models.Model):
    Name = models.CharField(max_length=20)
    Email = models.EmailField()
    Rating = models.IntegerField()
    Message = models.CharField(max_length=20)

class visitor(models.Model):
    Name = models.CharField(max_length=20)
    Email = models.EmailField()
    Phone = models.IntegerField()
    Message = models.CharField(max_length=20)

# Create your models here.
