from django import forms
from .models import user,visitor
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User





class signup(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']


class Feedback(forms.ModelForm):
    class Meta:
        model = user
        fields = ['Name', 'Email', 'Rating', 'Message']


class Visitordetails(forms.ModelForm):
    class Meta:
        model = visitor
        fields = ['Name','Email','Phone','Message']

