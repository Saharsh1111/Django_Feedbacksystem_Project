from django.shortcuts import render,redirect
from .forms import signup,Feedback,Visitordetails
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
def home(request):
    return render(request,'home.html')
def about(request):
    return render(request,'about.html')

def contact(request):
    if request.method == "POST":
        c1 = Visitordetails(request.POST)
        if c1.is_valid():
            c1.save()
    else:
        c1 = Visitordetails()
    return render(request, 'contact.html', {'visitor': c1})
def register(request):
    if request.method == "POST":
        fm = signup(request.POST)
        if fm.is_valid():
            fm.save()
            return redirect("/signin")
    else:
        fm = signup()
    return render(request,'signup.html',{'form': fm})

def signin(request):
    if request.method == "POST":
        fm = AuthenticationForm(request=request, data=request.POST)
        if fm.is_valid():
            uname = fm.cleaned_data['username']
            upass = fm.cleaned_data['password']
            user = authenticate(username=uname, password=upass)
            # feed = FeedbackEntry()
            if user is not None:
                login(request, user)
                # return render(request, 'feedback.html',{'user': user, 'form': feed})
                return redirect("/feedback")

    else:
        fm = AuthenticationForm()
    return render(request, "signin.html", {'form': fm})

def feedback(request):
    if request.method == "POST":
        fm = Feedback(request.POST)
        if fm.is_valid():
            fm.save()

    else:
        fm = Feedback()
    return render(request,'feedback.html',{'feed':fm})
def cources(request):
    return render(request,'cources.html')

def python(request):
    return render(request,'python.html')

def aws(request):
    return render(request,'aws.html')

def datascience(request):
    return render(request,'datascience.html')

def selenium(request):
    return render(request,'selenium.html')


def datasciencepy(request):
    return render(request,'datasciencepy.html')


def tableau(request):
    return render(request,'tableau.html')


def signout(request):
    logout(request)
    return redirect("/signin")







# Create your views here.

